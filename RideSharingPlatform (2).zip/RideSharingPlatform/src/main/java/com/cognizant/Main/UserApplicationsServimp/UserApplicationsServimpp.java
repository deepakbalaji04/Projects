package com.cognizant.Main.UserApplicationsServimp;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.Main.DTO.UserApplicationsDTO;
import com.cognizant.Main.DTO.userdrivingDTO;
import com.cognizant.Main.Entities.Companies;
import com.cognizant.Main.Entities.DrivingLicenses;
import com.cognizant.Main.Entities.UserApplications;
import com.cognizant.Main.Repository.CompaniesRepository;
import com.cognizant.Main.Repository.DrivingLicensesRepository;
import com.cognizant.Main.Repository.UserApplicationRepository;
import com.cognizant.Main.Service.UserApplicationsServ;
import com.cognizant.Main.utilities.ApplicationStatus;
import com.cognizant.Main.utilities.DLIdGenerator;
import com.cognizant.Main.utilities.InvalidMotoristRegistration;
import com.cognizant.Main.utilities.Role;
import com.cognizant.Main.utilities.UserIdGenerator;
import com.cognizant.Main.DTO.CompaniesDTO;
import com.cognizant.Main.Entities.Companies;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import jakarta.transaction.Transactional;

@Service("UserApplicationsServimpp")
@Transactional
public class UserApplicationsServimpp implements UserApplicationsServ{
	
	@Autowired
	private  UserApplicationRepository userrepo;
	
	@Autowired
	private  DrivingLicensesRepository dlrepo;
	
	@Autowired
	private  CompaniesRepository cmrepo;
	
	//@Autowired
	//private static UserIdGenerator uGen;
	
	//@Autowired
	//private static DLIdGenerator dgen;
	

	
public String adduser(userdrivingDTO userdto) throws InvalidMotoristRegistration{
	
	UserApplications addeduser=null;
	UserApplications u=new UserApplications();
	DrivingLicenses dl=new DrivingLicenses();
	u.setUsername(userdto.getUserNme());
	u.setOfficialEmail(userdto.getOfficialEmail());
	u.setPhoneNumber(userdto.getPhoneNumber());
	u.setDesignation(userdto.getDesignation());
	
	String role= userdto.getRole().getVal();
	System.out.println(role);
	if(role.equals("motorist")) {
		u.setRole(Role.MOTORIST);
		//Optional<UserApplications> useridop=userrepo.findById(userdto.getUserId());
		//dl.setUser(useridop.get());
		String lno = userdto.getLicenseNo();
		LocalDate expdate=userdto.getExpirationDate();
		String rta=userdto.getRta();
		String allowedvh=userdto.getAllowedVehicles();
		
		if(lno!=null && rta!=null && allowedvh!=null && expdate!=null ) {
		
			u.setAadharNumber(userdto.getAadharNumber());
			u.setApplicationStatus(userdto.getApplicationStatus());
			u.setEmployeeId(userdto.getEmployeeId());
			Optional<Companies> compo=cmrepo.findById(userdto.getCompanyId());
			System.out.println(compo.get());
			if(compo.isPresent()) {
			u.setCompanyId(compo.get());
			}
			addeduser=userrepo.save(u);
			System.out.println("************add user**********"+addeduser);
			System.out.println("********find**********"+userrepo.findById(addeduser.getUserId()));
			
			
			dl.setAllowedVehicles(allowedvh);
			dl.setExpirationDate(expdate);
			dl.setLicenseNo(lno);
			dl.setRTA(rta);
			dl.setUser(userrepo.findById(addeduser.getUserId()).get());
			dlrepo.save(dl);
			
			
		}
		else {
			throw new InvalidMotoristRegistration();
		}
	}
	else if(role.equals("securityhead")) {
		u.setRole(Role.SECURITYHEAD);
		u.setAadharNumber(userdto.getAadharNumber());
		u.setApplicationStatus(userdto.getApplicationStatus());
		u.setEmployeeId(userdto.getEmployeeId());
		Optional<Companies> compo=cmrepo.findById(userdto.getCompanyId());
		if (compo.isPresent())
		{
			u.setCompanyId(compo.get());
		}
		//u.setCompanyId(compo.get());
		addeduser=userrepo.save(u);
	}
	else {
		u.setRole(Role.RIDER);
		u.setAadharNumber(userdto.getAadharNumber());
		u.setApplicationStatus(userdto.getApplicationStatus());
		u.setEmployeeId(userdto.getEmployeeId());
		Optional<Companies> compo=cmrepo.findById(userdto.getCompanyId());
		if (compo.isPresent())
		{
			u.setCompanyId(compo.get());
		}
		addeduser=userrepo.save(u);
	}
	
	if(addeduser!=null) {
		return "success";
	}
	else {
		return "fail";
	}
	
	//return null;
}
	
	public String updateapprovereject(int UserId,UserApplicationsDTO userdto) {
		Optional<UserApplications> usercheck=userrepo.findById(UserId);
//		UserApplications statusupdated=null;
		if(usercheck.isPresent()) {
			
			UserApplications existing = usercheck.get();
			existing.setApplicationStatus(userdto.getApplicationstatus());
//			statusupdated=userrepo.save(existing);
			
			UserApplications statusupdated = userrepo.save(existing);
			if(statusupdated!=null) {
				return "success";
			}
//			System.out.println("INSIDE OFG IF");
//			UserApplications u=new UserApplications();
//			u.setApplicationStatus(userdto.getApplicationstatus());
//			statusupdated=userrepo.save(u);
		}
			return "fail";
		
	}
	
	public UserApplicationsDTO getUserById(int userid) {
		Optional<UserApplications> users= userrepo.findById(userid);
		UserApplicationsDTO usersDTO=new UserApplicationsDTO();
		if(users.isPresent()) {
			UserApplications u=users.get();
			usersDTO.setUserId(u.getUserId());
			usersDTO.setUsername(u.getUsername());
			usersDTO.setOfficialEmail(u.getOfficialEmail());
			usersDTO.setPhoneNumber(u.getPhoneNumber());
			usersDTO.setCompany(u.getCompanyId());
			usersDTO.setDesignation(u.getDesignation());
			usersDTO.setRole(u.getRole());
			usersDTO.setEmployeeId(u.getEmployeeId());
			usersDTO.setAadharNumber(u.getAadharNumber());
			usersDTO.setApplicationstatus(u.getApplicationStatus());
			return usersDTO;
		}
		return null;
	}
	
	public  List<CompaniesDTO> getCompaniesDetails(){
		List<Companies> companieslist=cmrepo.findAll();
		List<CompaniesDTO> companiesdtolist=new ArrayList<CompaniesDTO>();
		
		for(Companies company: companieslist) {
			CompaniesDTO companydto=new CompaniesDTO();
			companydto.setId(company.getId());
			companydto.setCompanyName(company.getCompanyName());
		    companydto.setBuildingName(company.getBuildingName());
		    companydto.setSecurityInchargeName(company.getSecurityInchargeName());
		    companydto.setSecurityHelpDeskNumber(company.getSecurityHelpDeskNumber());
		    companiesdtolist.add(companydto);
		}
		return companiesdtolist;
	}
	
	public List<UserApplicationsDTO> getpending(){
		List<UserApplications> userslist=userrepo.findAll();
		List<UserApplicationsDTO> usersdtolist=new ArrayList<UserApplicationsDTO>();
		
		for(UserApplications users: userslist) {
			UserApplicationsDTO usersdto=new UserApplicationsDTO();
			String status = users.getApplicationStatus().getVal();
			
			if(status.equalsIgnoreCase("NEW")) {
				
				usersdto.setUserId(users.getUserId());
				usersdto.setUsername(users.getUsername());
				usersdto.setOfficialEmail(users.getOfficialEmail());
				usersdto.setPhoneNumber(users.getPhoneNumber());
				usersdto.setCompany(users.getCompanyId());
				usersdto.setDesignation(users.getDesignation());
				usersdto.setRole(users.getRole());
				usersdto.setEmployeeId(users.getEmployeeId());
				usersdto.setAadharNumber(users.getAadharNumber());
				usersdto.setApplicationstatus(users.getApplicationStatus());
				usersdtolist.add(usersdto);
			}
			else {
				continue;
			}
		}
		System.out.println(usersdtolist);
		return usersdtolist;
	}

}
