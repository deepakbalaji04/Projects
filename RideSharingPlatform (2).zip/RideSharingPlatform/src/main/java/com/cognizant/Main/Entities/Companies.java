package com.cognizant.Main.Entities;

import java.util.Objects;

import org.hibernate.annotations.CascadeType;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import java.util.List;

@Entity
@Table(name="Companies")
public class Companies {
	
	@jakarta.persistence.Id
	@Column(name="id")
	private int Id;
	
	@Column(name="company_name")
	private String CompanyName;
	
	@Column(name="building_name")
	private String BuildingName;
	
	@Column(name="security_incharge_name")
	private String SecurityInchargeName;
	
	//@Pattern(regexp = "\\d{10}", message = "Security help desk number must be 10 digits")
	@Column(name="security_help_desk_number")
	private String SecurityHelpDeskNumber;
	
	

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		this.Id = id;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		this.CompanyName = companyName;
	}

	public String getBuildingName() {
		return BuildingName;
	}

	public void setBuildingName(String buildingName) {
		this.BuildingName = buildingName;
	}

	public String getSecurityInchargeName() {
		return SecurityInchargeName;
	}

	public void setSecurityInchargeName(String securityInchargeName) {
		this.SecurityInchargeName = securityInchargeName;
	}

	public String getSecurityHelpDeskNumber() {
		return SecurityHelpDeskNumber;
	}

	public void setSecurityHelpDeskNumber(String securityHelpDeskNumber) {
		this.SecurityHelpDeskNumber = securityHelpDeskNumber;
	}
	
}