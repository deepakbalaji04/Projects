package com.cognizant.Main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.cognizant.*")
@EnableJpaRepositories(basePackages = "com.cognizant.Main.Repository")
@EntityScan(basePackages = "com.cognizant.Main.Entities")
public class RideSharingPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(RideSharingPlatformApplication.class, args);
		System.out.println("Hello World");
	}

}
