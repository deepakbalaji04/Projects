package com.cognizant.Main.utilities;

public enum Role {
	MOTORIST("motorist"),
	RIDER("rider"),
	SECURITYHEAD("securityhead");
	String val;
	private Role(String val) {
		this.val=val;
	}
	
	public String getVal() {
		return val;
	}
}
