package com.cognizant.Main.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.Main.Entities.Companies;

@Repository
public interface CompaniesRepository extends JpaRepository<Companies,Integer>{

	Optional<Companies> findById(Companies companyId);
	//Iterable<Companies> findAll();
 
	


}
