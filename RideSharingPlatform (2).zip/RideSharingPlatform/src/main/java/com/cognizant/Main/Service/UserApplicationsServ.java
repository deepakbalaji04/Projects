package com.cognizant.Main.Service;

import com.cognizant.Main.DTO.UserApplicationsDTO;
import com.cognizant.Main.DTO.userdrivingDTO;
import com.cognizant.Main.Entities.DrivingLicenses;
import com.cognizant.Main.utilities.InvalidMotoristRegistration;
import com.cognizant.Main.DTO.CompaniesDTO;
import java.util.List;

public interface UserApplicationsServ {

	public   String adduser(userdrivingDTO userdto) throws InvalidMotoristRegistration;
	public  String updateapprovereject(int UserId,UserApplicationsDTO userdto);
	public  UserApplicationsDTO getUserById(int userid);
	public List<CompaniesDTO> getCompaniesDetails();

	
	public  List<UserApplicationsDTO> getpending();
	
	
}
