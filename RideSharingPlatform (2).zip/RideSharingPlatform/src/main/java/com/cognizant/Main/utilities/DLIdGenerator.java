package com.cognizant.Main.utilities;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

@Component
public class DLIdGenerator {
	
	private static final AtomicInteger counter=new AtomicInteger(1);
	
	public int generate() {
		//Random rand=new Random();
		//Integer randno = rand.nextInt(1000);
		//return randno;
		return counter.getAndIncrement();
	}

}
