package com.cognizant.Main.utilities;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

@Component
public class UserIdGenerator {
	
	private static final AtomicInteger counter=new AtomicInteger(1);
	
	
	public int generate() {
		//Random rand=new Random();
		//int max=100,min=50;
		//int randno = rand.nextInt(max-min+1)+min;
		return counter.getAndIncrement();
		//return randno;
	}

}
