package com.cognizant.Main.DTO;

import com.cognizant.Main.Entities.Companies;
import com.cognizant.Main.utilities.ApplicationStatus;
import com.cognizant.Main.utilities.Role;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Pattern;

public class UserApplicationsDTO {

	
	@Column(name="UserId")
	private int UserId;
	
	
	
	@Column(name="CompanyId")
	private Companies company;
	
	@Column(name="Username")
	private String Username;
	
	@Column(name="OfficialEmail")
	private String OfficialEmail;
	
	@Pattern(regexp = "^(?=[9])\\\\d{9}$", message = "Phone number must be 10 digits and should start with 9")
	@Column(name="PhoneNumber")
	private String PhoneNumber;
	
	@Column(name="Designation")
	private String Designation;
	
	@Column(name="Role")
	@Enumerated(EnumType.STRING)
	private Role Role;
	
	@Column(name="EmployeeId")
	private String EmployeeId;
	
	@Pattern(regexp = "\\d{12}", message = "Aadhar number must be 12 digits")
	@Column(name="AadharNumber")
	private String AadharNumber;
	
	@Column(name="ApplicationStatus")
	@Enumerated(EnumType.STRING)
	private ApplicationStatus applicationstatus;

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public Companies getCompany() {
		return company;
	}

	public void setCompany(Companies company) {
		this.company = company;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getOfficialEmail() {
		return OfficialEmail;
	}

	public void setOfficialEmail(String officialEmail) {
		OfficialEmail = officialEmail;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public Role getRole() {
		return Role;
	}

	public void setRole(Role role) {
		Role = role;
	}

	public String getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(String employeeId) {
		EmployeeId = employeeId;
	}

	public String getAadharNumber() {
		return AadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		AadharNumber = aadharNumber;
	}

	public ApplicationStatus getApplicationstatus() {
		return applicationstatus;
	}

	public void setApplicationstatus(ApplicationStatus applicationstatus) {
		this.applicationstatus = applicationstatus;
	}
	
}