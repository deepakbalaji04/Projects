create table companies(
  id int,
  company_name varchar(100) ,
  building_name varchar(10),
  security_incharge_name varchar(30),
  security_help_desk_number varchar(10),
  primary key(id)
  
);


create table User_Applications(
   user_id int auto_increment,
   UserName varchar(50),
   official_email varchar(50),
   phone_number varchar(10),
   company_id int,
   designation varchar(50),
   role ENUM('motorist','rider','securityhead'),
   employee_id varchar(10),
   aadhar_number varchar(12),
   application_status ENUM('new','approved','rejected') ,
   primary key(user_id),
   foreign key(company_id) references companies(id)

);

create table Driving_Licenses(
    id int auto_increment,
    license_no varchar(12),
    expiration_date date,
    rta varchar(20),
    allowed_vehicles varchar(100),
    primary key(id)
    );


