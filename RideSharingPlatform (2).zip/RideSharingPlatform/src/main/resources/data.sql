insert into companies (id,company_name,building_name,security_incharge_name,security_help_desk_number)
    values(1,'Cognizant','BuildingA','David','1234567890');

insert into User_Applications(user_id,UserName,official_email,phone_number,company_id,designation,role,employee_id,aadhar_number,application_status)
     values(2,'Deepak','abc@email.com','9841099807',1,'incharge','SECURITYHEAD','emp1','123456789012','NEW'),
     (3,'harini','abc@email.com','9841099808',1,'incharge','SECURITYHEAD','emp','123456789012','NEW');
 
     