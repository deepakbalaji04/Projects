package com.cognizant.Main;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import com.cognizant.Main.Controller.UserApplicationsCon;
import com.cognizant.Main.DTO.CompaniesDTO;
import com.cognizant.Main.DTO.UserApplicationsDTO;
import com.cognizant.Main.DTO.userdrivingDTO;
import com.cognizant.Main.Entities.Companies;
import com.cognizant.Main.UserApplicationsServimp.UserApplicationsServimpp;
import com.cognizant.Main.utilities.ApplicationStatus;
import com.cognizant.Main.utilities.InvalidMotoristRegistration;
import com.cognizant.Main.utilities.Role;
import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootTest(classes = RideSharingPlatformApplication.class)
public class TestUserApplicationsCon {
	
	private MockMvc mockMvc;
	
	@Mock
	private UserApplicationsServimpp user;
	
	@InjectMocks
	private UserApplicationsCon usercontroller;
	
	    @Mock
	    private RestTemplate restTemplate;
	    
	    private MockRestServiceServer mockServer;
	    private RestTemplate template;
	    private ObjectMapper mapper=new ObjectMapper();
	    
	    @BeforeEach
	    public void setUp() {
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders.standaloneSetup(usercontroller).build();
	        template = new RestTemplate();
	        mockServer = MockRestServiceServer.createServer(template);
	        
	    }
	    
	    @Test
	    public void testReturnAllCompaniesPositive() {
	    	List<CompaniesDTO> companiesdtolist=new ArrayList<>();
	    	CompaniesDTO c=new CompaniesDTO();
	    	c.setId(2);
	    	c.setBuildingName("CognizantB");
	    	c.setCompanyName("Cognizant1");
	    	c.setSecurityHelpDeskNumber("1234567890");
	    	c.setSecurityInchargeName("Deepak");
	    	companiesdtolist.add(c);
	    	Mockito.when(user.getCompaniesDetails()).thenReturn(companiesdtolist);
	    	List<CompaniesDTO> responselist = usercontroller.getDetails().getBody();
	    	assertTrue(!responselist.isEmpty());
	    	assertEquals(companiesdtolist.size(),responselist.size());
	    	
	    }
	    
	    @Test
	    public void testReturnAllCompaniesNegative() {
	    	List<CompaniesDTO> companiesdtolist=new ArrayList<>();
	    	Mockito.when(user.getCompaniesDetails()).thenReturn(companiesdtolist,null);
	    	ResponseEntity<?> responseEntity= usercontroller.getDetails();
	    	List<CompaniesDTO> responseList=(List<CompaniesDTO>) responseEntity.getBody();
	    	//assertNull(responseList);
	    	assertEquals(responseList.size(),0);
	    }
	    
	    @Test
	    public void testUriReturnAllCompaniesPositive() {
	    	List<CompaniesDTO> companiesdtolist=new ArrayList<>();
	    	CompaniesDTO c=new CompaniesDTO();
	    	c.setId(2);
	    	c.setBuildingName("CognizantB");
	    	c.setCompanyName("Cognizant1");
	    	c.setSecurityHelpDeskNumber("1234567890");
	    	c.setSecurityInchargeName("Deepak");
	    	companiesdtolist.add(c);
	    	Mockito.when(user.getCompaniesDetails()).thenReturn(companiesdtolist);
	    	try {
	    		MvcResult mockMvcResult = mockMvc.perform(get("http://localhost:8080/api/applications/companies")).andExpect(status().isOk()).andReturn();
	    	}
	    	catch(Exception e) {
	    		assertTrue(false);
	    	}
	    }
//	    
//	    @Test
//	    public void testUriReturnAllCompaniesNegative() {
//	    	Mockito.when(null);
//	    	try {
//	    		mockMvc.perform(get("http://localhost:8080/api/applications/companies")).andExpect(status().isBadRequest()).andReturn();
//	    	}
//	    	catch(Exception e) {
//	    		assertTrue(true);
//	    	}
//	    }
	    
	    @Test
	    public void testgetuserbyidPositive() {
	    	Companies c=new Companies();
	    	c.setId(2);
	    	c.setBuildingName("CognizantB");
	    	c.setCompanyName("Cognizant1");
	    	c.setSecurityHelpDeskNumber("1234567890");
	    	c.setSecurityInchargeName("Deepak");
	    	UserApplicationsDTO  u=new UserApplicationsDTO();
	    	u.setUserId(5);
			u.setUsername("David");
			u.setOfficialEmail("abc@email.com");
			u.setEmployeeId("123");
			u.setPhoneNumber("9841099807");
			u.setDesignation("Developer");
			u.setCompany(c);
		    u.setAadharNumber("123456789012");
		    u.setApplicationstatus(ApplicationStatus.APPROVED);
		    u.setRole(Role.MOTORIST);
		    
		    when(user.getUserById(5)).thenReturn(u);
		    ResponseEntity<?> responseEntity=usercontroller.getById(5);
		    assertEquals(200,responseEntity.getStatusCodeValue());
	    	
	    }
	    
	    @Test
	    public void testgetuserbyidNegative() {
	    	UserApplicationsDTO  u=new UserApplicationsDTO();
	    	 when(user.getUserById(1)).thenReturn(u);
	    	 ResponseEntity<?> responseEntity=usercontroller.getById(5);
	    	 assertEquals(400,responseEntity.getStatusCodeValue());
	    }
	    
	    @Test
	    public void testaddUserPositive() throws InvalidMotoristRegistration {
	    	
	    	
	    	Companies c=new Companies();
	    	c.setId(2);
	    	c.setBuildingName("CognizantB");
	    	c.setCompanyName("Cognizant1");
	    	c.setSecurityHelpDeskNumber("1234567890");
	    	c.setSecurityInchargeName("Deepak");
	    	
	    	userdrivingDTO  u=new userdrivingDTO();
	    	u.setUserId(5);
			u.setUserNme("David");
			u.setOfficialEmail("abc@email.com");
			u.setEmployeeId("123");
			u.setPhoneNumber("9841099807");
			u.setDesignation("Developer");
			u.setCompanyId(2);
		    u.setAadharNumber("123456789012");
		    u.setApplicationStatus(ApplicationStatus.APPROVED);
		    u.setRole(Role.RIDER);
		    when(user.adduser(u)).thenReturn("success");
		  ResponseEntity<?> responseEntity=usercontroller.adduser(u);
		    assertEquals(200,responseEntity.getStatusCodeValue());
		    
	    }
	    
	    
	    
	    @Test
	    public void testaddUserNegative() throws InvalidMotoristRegistration {
	    	userdrivingDTO usersdto=new userdrivingDTO();
//	    	Companies c=new Companies();
//	    	c.setId(2);
//	    	c.setBuildingName("CognizantB");
//	    	c.setCompanyName("Cognizant1");
//	    	c.setSecurityHelpDeskNumber("1234567890");
//	    	c.setSecurityInchargeName("Deepak");
//	    	
//	    	userdrivingDTO  u=new userdrivingDTO();
//	    	u.setUserId(5);
//			u.setUserNme("David");
//			u.setOfficialEmail("abc@email.com");
//			u.setEmployeeId("123");
//			u.setPhoneNumber("9841099807");
//			u.setDesignation("Developer");
//			u.setCompanyId(2);
//		    u.setAadharNumber("123456789012");
//		    u.setApplicationStatus(ApplicationStatus.APPROVED);
//		    u.setRole(Role.RIDER);
	    	when(user.adduser(usersdto)).thenReturn("fail");
	    	ResponseEntity<?> responseEntity=usercontroller.adduser(usersdto);
	    	assertEquals(400, responseEntity.getStatusCodeValue());
	    }
	    
	    @Test
	    public void testgetpending_Positive() {
	    	Companies c=new Companies();
	    	c.setId(2);
	    	c.setBuildingName("CognizantB");
	    	c.setCompanyName("Cognizant1");
	    	c.setSecurityHelpDeskNumber("1234567890");
	    	c.setSecurityInchargeName("Deepak");
	    	
	    	UserApplicationsDTO  u=new UserApplicationsDTO();
	    	u.setUserId(5);
			u.setUsername("David");
			u.setOfficialEmail("abc@email.com");
			u.setEmployeeId("123");
			u.setPhoneNumber("9841099807");
			u.setDesignation("Developer");
			u.setCompany(c);
		    u.setAadharNumber("123456789012");
		    u.setApplicationstatus(ApplicationStatus.NEW);
		    u.setRole(Role.MOTORIST);
		    List<UserApplicationsDTO> userslist=new ArrayList<>();
		    userslist.add(u);
		    Mockito.when(user.getpending()).thenReturn(userslist);
		    List<UserApplicationsDTO> responselist=usercontroller.getPendingDetails().getBody();
		    assertTrue(!responselist.isEmpty());
		    assertEquals(userslist.size(),responselist.size());
		    
	    	
	    	
	    }
	   
	    
	    
	    

}
