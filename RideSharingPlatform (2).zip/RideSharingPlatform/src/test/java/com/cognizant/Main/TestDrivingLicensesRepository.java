package com.cognizant.Main;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.cognizant.Main.Entities.Companies;
import com.cognizant.Main.Entities.DrivingLicenses;
import com.cognizant.Main.Entities.UserApplications;
import com.cognizant.Main.Repository.CompaniesRepository;
import com.cognizant.Main.Repository.DrivingLicensesRepository;
import com.cognizant.Main.Repository.UserApplicationRepository;
import com.cognizant.Main.utilities.ApplicationStatus;
import com.cognizant.Main.utilities.Role;

@DataJpaTest
class TestDrivingLicensesRepository {

	@Autowired
	private UserApplicationRepository user;
	
	@Autowired
	private CompaniesRepository company;
	
	@Autowired
	private DrivingLicensesRepository driving;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void testFindAllPositive() {
		Companies c=new Companies();
		c.setId(3);
	c.setCompanyName("CognizantA");
		c.setBuildingName("BuildingB");
		
	c.setSecurityInchargeName("Deepak");
		c.setSecurityHelpDeskNumber("1234567890");
		
		company.save(c);
		
		UserApplications users=new UserApplications();
		users.setUserId(5);
		users.setUsername("John");
		users.setOfficialEmail("abc@gmail.com");
		users.setPhoneNumber("1234567890");
		users.setCompanyId(c);
		users.setDesignation("Developer");
		users.setRole(Role.MOTORIST);
		users.setEmployeeId("123");
		users.setAadharNumber("123456789012");
		users.setApplicationStatus(ApplicationStatus.NEW);
		
		user.save(users);
		
		DrivingLicenses d=new DrivingLicenses();
		d.setId(5);
		d.setUser(users);
		d.setLicenseNo("AB1");
		d.setExpirationDate(LocalDate.now());
		d.setRTA("AB2");
		d.setAllowedVehicles("car");
		
		//driving.save(d);
		//entityManager.persist(c);
	  //entityManager.persist(users);
	Iterable<DrivingLicenses> it= driving.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
//	@Test
//	public void testFindByIdPositive() {
//		Companies c=new Companies();
//		c.setId(1);
//		c.setCompanyName("Cognizant");
//		c.setBuildingName("BuildingA");
//		
//		c.setSecurityInchargeName("Deepak");
//		c.setSecurityHelpDeskNumber("1234567890");
//		
//		UserApplications users=new UserApplications();
//		users.setUserId(2);
//		users.setUsername("John");
//		users.setOfficialEmail("abc@gmail.com");
//		users.setPhoneNumber("1234567890");
//		users.setCompanyId(c);
//		users.setDesignation("Developer");
//		users.setRole(Role.MOTORIST);
//		users.setEmployeeId("123");
//		users.setAadharNumber("123456789012");
//		users.setApplicationStatus(ApplicationStatus.NEW);
//		
//		DrivingLicenses d=new DrivingLicenses();
//		d.setId(4);
//		d.setUser(users);
//		d.setLicenseNo("AB1");
//		d.setExpirationDate(LocalDate.now());
//		d.setRTA("AB2");
//		d.setAllowedVehicles("car");
//		
//		entityManager.persist(c);
//		entityManager.persist(users);
//		entityManager.persist(d);
//		Optional<DrivingLicenses> dl= driving.findById(4);
//		assertTrue(dl.isPresent());
//	}
	
	@Test
	  public void testFindAllNegative() {
		Iterable<DrivingLicenses> it=driving.findAll();
		assertFalse(it.iterator().hasNext());
	}
	
//	@Test
//	public void testDeletePositive() {
//		Companies c=new Companies();
//		c.setId(1);
//		c.setCompanyName("Cognizant");
//		c.setBuildingName("BuildingA");
//		
//		c.setSecurityInchargeName("Deepak");
//		c.setSecurityHelpDeskNumber("1234567890");
//		entityManager.persist(c);
//	//company.delete(c);
//	UserApplications users=new UserApplications();
//	users.setUserId(2);
//	users.setUsername("John");
//	users.setOfficialEmail("abc@gmail.com");
//	users.setPhoneNumber("1234567890");
//	users.setCompanyId(c);
//	users.setDesignation("Developer");
//	users.setRole(Role.MOTORIST);
//	users.setEmployeeId("123");
//	users.setAadharNumber("123456789012");
//	users.setApplicationStatus(ApplicationStatus.NEW);
//	//user.delete(users);
//	
//	DrivingLicenses d=new DrivingLicenses();
//	d.setId(4);
//	d.setUser(users);
//	d.setLicenseNo("AB1");
//	d.setExpirationDate(LocalDate.now());
//	d.setRTA("AB2");
//	d.setAllowedVehicles("car");
//	entityManager.persist(users);
//	entityManager.persist(d);
//	driving.delete(d);
//	Optional<DrivingLicenses> dl=driving.findById(4);
//	//List<DrivingLicenses> dl=driving.findAll();
//	assertFalse(dl.isPresent());
//	
//	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<DrivingLicenses> dl=driving.findById(4);
		assertFalse(dl.isPresent());
	}
	
//	@Test
//    public void testSavePositive() {
//    	Companies c=new Companies();
//    		c.setId(1);
//    		c.setCompanyName("Cognizant");
//    	c.setBuildingName("BuildingA");
//    	
//    		c.setSecurityInchargeName("Deepak");
//    		c.setSecurityHelpDeskNumber("1234567890");
//    	
//    	company.save(c);
//    		UserApplications users=new UserApplications();
//    		users.setUserId(2);
//    		users.setUsername("John");
//    		users.setOfficialEmail("abc@gmail.com");
//    		users.setPhoneNumber("1234567899");
//    		users.setCompanyId(c);
//    		users.setDesignation("Developer");
//    		users.setRole(Role.MOTORIST);
//    		users.setEmployeeId("123");
//    		users.setAadharNumber("123456789012");
//    		users.setApplicationStatus(ApplicationStatus.NEW);
//    		user.save(users);
//    		
//    		DrivingLicenses d=new DrivingLicenses();
//    		d.setId(4);
//    		d.setUser(users);
//    		d.setLicenseNo("AB1");
//    		d.setExpirationDate(LocalDate.now());
//    		d.setRTA("AB2");
//    		d.setAllowedVehicles("car");
//    		driving.save(d);
//    		
//    	Optional<DrivingLicenses> dl=driving.findById(4);
//    	assertTrue(dl.isPresent());
//    	}
 

}
