package com.cognizant.Main;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.Main.Entities.Companies;
import com.cognizant.Main.Repository.CompaniesRepository;

@DataJpaTest
class TestCompaniesRepository {
	
	@Autowired
	private CompaniesRepository company;
	
	@Autowired
	private TestEntityManager entityManager;

	
	
	@Test
	public void testFindAllPositive() {
		//Companies c=new Companies();
		//c.setId(1);
	//c.setCompanyName("Cognizant");
		//c.setBuildingName("BuildingA");
		
	//c.setSecurityInchargeName("Deepak");
		//c.setSecurityHelpDeskNumber("1234567890");
		
	//entityManager.persist(c);
	Iterable<Companies> it= company.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindByIdPositive() {
		Companies c=new Companies();
		c.setId(1);
		c.setCompanyName("Cognizant");
		c.setBuildingName("BuildingA");
		
		c.setSecurityInchargeName("Deepak");
		c.setSecurityHelpDeskNumber("1234567890");
		
		
		entityManager.persist(c);
		Optional<Companies> com= company.findById(1);
		assertTrue(com.isPresent());
	}
	
	 @Test
	  public void testFindAllNegative() {
		Iterable<Companies> it=company.findAll();
		assertFalse(!it.iterator().hasNext());
	}
	
	@Test
	public void testDeletePositive() {
		Companies c=new Companies();
		c.setId(1);
		c.setCompanyName("Cognizant");
		c.setBuildingName("BuildingA");
		
		c.setSecurityInchargeName("Deepak");
		c.setSecurityHelpDeskNumber("1234567890");
		entityManager.persist(c);
	company.delete(c);
	Optional<Companies> companies=company.findById(1);
	assertFalse(companies.isPresent());
	
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Companies> companies=company.findById(5);
		assertFalse(companies.isPresent());
	}
//
@Test
public void testSavePositive() {
	Companies c=new Companies();
		c.setId(1);
		c.setCompanyName("Cognizant");
	c.setBuildingName("BuildingA");
	
		c.setSecurityInchargeName("Deepak");
		c.setSecurityHelpDeskNumber("1234567890");
	
	company.save(c);
	Optional<Companies> companies=company.findById(1);
	assertTrue(companies.isPresent());
	}

}
