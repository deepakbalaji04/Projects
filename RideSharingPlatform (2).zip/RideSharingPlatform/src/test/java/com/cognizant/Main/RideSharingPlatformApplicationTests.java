package com.cognizant.Main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideSharingPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
